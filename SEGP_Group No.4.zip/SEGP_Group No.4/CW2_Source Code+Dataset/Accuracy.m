function map = Accuracy(ActualOutput, Predicted)
    count = 0;
    for k = 1 : length(ActualOutput)
        if ActualOutput(k) == Predicted(k)
            count = count+1;
        end
    end
    percentageAccuracy = (count/length(ActualOutput))*100;
    map = percentageAccuracy;
end