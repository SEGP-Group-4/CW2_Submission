% Get list of all jpg files in this directory
% DIR returns as a structure array.  You will need to use () and . to get
% the file names.
imagefiles = dir('*.jpg');      
nfiles = length(imagefiles);    % Number of files found
 x =zeros(nfiles,3);
for i=1:nfiles
   currentfilename = imagefiles(i).name;
   currentImage=imread(currentfilename);
   rgb=RGBValues(currentImage);
   x(i,:)=rgb;
  
end
     [writeStatus, writeMsg] = xlswrite('dd.xlsx',x,'F2:H2');

