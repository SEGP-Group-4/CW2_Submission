function trained = TrainNN(net, TrainingInput, TrainingOutput)
    trained = train(net, TrainingInput', TrainingOutput');
end