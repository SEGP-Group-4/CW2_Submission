function Runner=Runner(Input)
%DataPreparation();
load('mynet.mat','mynet');
%mynet = Network(TrainingInput, TrainingOutput);
%save('mynet.mat','mynet');
%mytrained = TrainNN(mynet, TrainingInput, TrainingOutput);
%save('mytrained.mat','mytrained');
load('mytrained.mat','mytrained');
output_neural = TestNetwork(mytrained,Input);
replace_out = ReplacePredictedOutputWithOnesZeros(output_neural);
Runner=replace_out;
%map = Accuracy(TestingOutput, replace_out);