function im=RGBValues(img)
%img = imread('a.jpg'); % Read image
[r,c]=size(img);
red = img(:,:,1); % Red channel
green = img(:,:,2); % Green channel
blue = img(:,:,3); % Blue channel
M1 = mean(red,2);
M2 = mean(green,2);
M3 = mean(blue,2);
sum1=0;
sum2=0;
sum3=0;
for i = 1:r
   
    sum1=sum1+M1(i,1);
    sum2=sum2+M2(i,1);
    sum3=sum3+M3(i,1);
end
average1=sum1/r;
average2=sum2/r;
average3=sum3/r;
im=[average1,average2,average3];
end