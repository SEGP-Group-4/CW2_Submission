function net = Network(TrainingInput, TrainingOutput)
    net = newff(TrainingInput', TrainingOutput', [5 5], {'purelin' 'purelin' 'purelin'},'traingdx','traingdx', 'mse');
    net.trainParam.lr = 0.02;
    net.trainParam.epochs = 2000;
    net.trainParam.goal = 0.02;
    net.trainParam.max_fail=200;
end
