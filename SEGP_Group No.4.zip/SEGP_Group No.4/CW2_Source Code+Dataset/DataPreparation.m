TotalData = load('Data.m');
TrainingInput= TotalData((1:1000),(1:5));

TrainingOutput = TotalData((1:1000),(6));

TestingInput = TotalData((1001:1243),(1:5));

TestingOutput = TotalData((1001:1243),(6));