function rep = ReplacePredictedOutputWithOnesZeros(output)
    newMatrix = output;
    for k = 1 : length(output)
        newMatrix(output<0.5) = 0;
        newMatrix(output>=0.5) = 1;
    end
    rep = newMatrix;
end