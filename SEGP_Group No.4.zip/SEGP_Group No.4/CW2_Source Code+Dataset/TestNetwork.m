function out = TestNetwork(TrainedNetwork, TestingInput)
    out = sim(TrainedNetwork, TestingInput');
end